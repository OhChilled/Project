var cosmos2025_8cpp =
[
    [ "main", "cosmos2025_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "DOCKING_RADIUS", "cosmos2025_8cpp.html#a92942a186c2ec4e97ea8ea512406a8b1", null ],
    [ "HALF", "cosmos2025_8cpp.html#a41fce4c7218b88ea01b610ef01b3bc4e", null ],
    [ "INITIAL_POSITION", "cosmos2025_8cpp.html#acaf2f77b323f1a1e79876b5357c8d770", null ],
    [ "INITIAL_VELOCITY", "cosmos2025_8cpp.html#ac6ce7223a568a52b1d3a4dacd788f325", null ],
    [ "OMEGA", "cosmos2025_8cpp.html#af57c72b96ba26c19cf3a8502d5d56c7d", null ],
    [ "RK_DIVISOR", "cosmos2025_8cpp.html#aea1735d48e1f00fd08cae9a831f778c6", null ],
    [ "RK_WEIGHT", "cosmos2025_8cpp.html#a0765a1fea0ac30ec3f7d8a7ba0bc5823", null ],
    [ "TIME_END", "cosmos2025_8cpp.html#a7e2020001ff2c805566396981c5ba29c", null ],
    [ "TIME_START", "cosmos2025_8cpp.html#a14b913596a29ee0713a515b5bd7ea46d", null ],
    [ "TIME_STEP", "cosmos2025_8cpp.html#a922865f56011509eefa5867c1815de05", null ]
];