var dir_bf96cbeeb1ccefc31ff57ef52cb9c3f6 =
[
    [ "tests", "dir_a5abb26378549c5271f00d84f9daec53.html", "dir_a5abb26378549c5271f00d84f9daec53" ],
    [ "cosmos2025.cpp", "_project__backup_2cosmos2025_8cpp.html", "_project__backup_2cosmos2025_8cpp" ],
    [ "library.cpp", "_project__backup_2library_8cpp.html", "_project__backup_2library_8cpp" ],
    [ "library.h", "_project__backup_2library_8h.html", "_project__backup_2library_8h" ]
];