var struct_state =
[
    [ "x0", "struct_state.html#af2fc19492a74ec28db001d7a7f393dcf", null ],
    [ "x1", "struct_state.html#a67e37002829cab5b3754daffa353aaa2", null ],
    [ "y0", "struct_state.html#a13c588cc588581b9319110a263d60cb7", null ],
    [ "y1", "struct_state.html#a19340a40b8bab697847279ac86412590", null ]
];