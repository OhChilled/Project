var searchData=
[
  ['defaultvalue_3c_20t_20_26_20_3e_3a_3aaddress_5f_0',['address_',['../namespacetesting.html#a0dce5b99717740a6f010f10cd1d331ce',1,'testing']]],
  ['defaultvalue_3c_20t_20_3e_3a_3aproducer_5f_1',['producer_',['../namespacetesting.html#a247f6809c544e301e1f5e1d310604c05',1,'testing']]],
  ['docking_5fradius_2',['DOCKING_RADIUS',['../cosmos2025_8cpp.html#a92942a186c2ec4e97ea8ea512406a8b1',1,'cosmos2025.cpp']]],
  ['dummy_5f_3',['dummy_',['../classtesting_1_1internal_1_1_type_id_helper.html#a372268b1520d965d0bdf01ebad3d270e',1,'testing::internal::TypeIdHelper']]]
];
