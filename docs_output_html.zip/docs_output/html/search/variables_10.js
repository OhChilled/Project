var searchData=
[
  ['x0_0',['x0',['../struct_state.html#af2fc19492a74ec28db001d7a7f393dcf',1,'State']]],
  ['x1_1',['x1',['../struct_state.html#a67e37002829cab5b3754daffa353aaa2',1,'State']]]
];
