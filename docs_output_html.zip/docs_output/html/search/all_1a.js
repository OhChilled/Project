var searchData=
[
  ['y0_0',['y0',['../struct_state.html#a13c588cc588581b9319110a263d60cb7',1,'State']]],
  ['y1_1',['y1',['../struct_state.html#a19340a40b8bab697847279ac86412590',1,'State']]]
];
