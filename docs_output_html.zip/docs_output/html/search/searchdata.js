var indexSectionsWithContent =
{
  0: ":_abcdefghijklmnopqrstuvwxy~",
  1: "abcdefghiklmnopqrstuvw",
  2: "pst",
  3: "cglpst",
  4: "abcdefghijklmnopqrstuvwx~",
  5: "adfghiklmoprtuvwxy",
  6: "abcdfhilmprstuv",
  7: "efglrt",
  8: "ghikv",
  9: ":agipqstu",
  10: "_acdefghimoprst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros"
};

