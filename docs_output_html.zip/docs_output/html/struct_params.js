var struct_params =
[
    [ "ax", "struct_params.html#a26acf18c1fa645a9b8bdbcfc0be9dc03", null ],
    [ "ay", "struct_params.html#a9e0f40fc74c58adb5590f604cd51a42c", null ],
    [ "h", "struct_params.html#a1961e877dea1279a80e4a42c4415bcf0", null ],
    [ "omega", "struct_params.html#a8e1bfb0f85092ca1b0077f34f79451ab", null ],
    [ "Rcrit", "struct_params.html#a4f0e185921b7eeb51a0c26245192d072", null ]
];