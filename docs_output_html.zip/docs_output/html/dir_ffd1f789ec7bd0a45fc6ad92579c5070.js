var dir_ffd1f789ec7bd0a45fc6ad92579c5070 =
[
    [ "tests", "dir_8134e036958abec3d1496c9054c8e01b.html", "dir_8134e036958abec3d1496c9054c8e01b" ],
    [ "cosmos2025.cpp", "_project_2cosmos2025_8cpp.html", "_project_2cosmos2025_8cpp" ],
    [ "library.cpp", "_project_2library_8cpp.html", "_project_2library_8cpp" ],
    [ "library.h", "_project_2library_8h.html", "_project_2library_8h" ]
];