var files_dup =
[
    [ "build", "dir_4fef79e7177ba769987a8da36c892c5f.html", "dir_4fef79e7177ba769987a8da36c892c5f" ],
    [ "Project", "dir_ffd1f789ec7bd0a45fc6ad92579c5070.html", "dir_ffd1f789ec7bd0a45fc6ad92579c5070" ],
    [ "Project_backup", "dir_bf96cbeeb1ccefc31ff57ef52cb9c3f6.html", "dir_bf96cbeeb1ccefc31ff57ef52cb9c3f6" ],
    [ "tests", "dir_59425e443f801f1f2fd8bbe4959a3ccf.html", "dir_59425e443f801f1f2fd8bbe4959a3ccf" ],
    [ "cosmos2025.cpp", "cosmos2025_8cpp.html", "cosmos2025_8cpp" ],
    [ "library.cpp", "library_8cpp.html", "library_8cpp" ],
    [ "library.h", "library_8h.html", "library_8h" ]
];