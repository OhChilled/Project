var classtesting_1_1internal_1_1_type_with_size_3_014_01_4 =
[
    [ "Int", "classtesting_1_1internal_1_1_type_with_size_3_014_01_4.html#a1d8c184b21efa24728441dd11476c82d", null ],
    [ "UInt", "classtesting_1_1internal_1_1_type_with_size_3_014_01_4.html#a101d382e484e36b2c5625ee5d23cba07", null ]
];